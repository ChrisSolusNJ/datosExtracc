﻿Imports System.ServiceProcess

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class cl_P038LogMaquinas
    Inherits System.ServiceProcess.ServiceBase

    'UserService overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    ' The main entry point for the process
    <MTAThread()> _
    <System.Diagnostics.DebuggerNonUserCode()> _
    Shared Sub Main()
        Dim ServicesToRun() As System.ServiceProcess.ServiceBase

        ' More than one NT Service may run within the same process. To add
        ' another service to this process, change the following line to
        ' create a second service object. For example,
        '
        '   ServicesToRun = New System.ServiceProcess.ServiceBase () {New Service1, New MySecondUserService}
        '
        ServicesToRun = New System.ServiceProcess.ServiceBase() {New cl_P038LogMaquinas}

        System.ServiceProcess.ServiceBase.Run(ServicesToRun)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    ' NOTE: The following procedure is required by the Component Designer
    ' It can be modified using the Component Designer.  
    ' Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tmr01InicioServicio = New System.Timers.Timer()
        Me.tmr02Conexion = New System.Timers.Timer()
        Me.tmr03IniciaServicios = New System.Timers.Timer()
        Me.tmr05BitacoraAut = New System.Timers.Timer()
        CType(Me.tmr01InicioServicio, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tmr02Conexion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tmr03IniciaServicios, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tmr05BitacoraAut, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'tmr01InicioServicio
        '
        Me.tmr01InicioServicio.Interval = 5000.0R
        '
        'tmr02Conexion
        '
        Me.tmr02Conexion.Interval = 5000.0R
        '
        'tmr03IniciaServicios
        '
        Me.tmr03IniciaServicios.Interval = 2000.0R
        '
        'tmr05BitacoraAut
        '
        Me.tmr05BitacoraAut.Interval = 20000.0R
        '
        'cl_P038LogMaquinas
        '
        Me.ServiceName = "LogServMaquinas"
        CType(Me.tmr01InicioServicio, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tmr02Conexion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tmr03IniciaServicios, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tmr05BitacoraAut, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Friend WithEvents tmr01InicioServicio As System.Timers.Timer
    Friend WithEvents tmr02Conexion As System.Timers.Timer
    Friend WithEvents tmr03IniciaServicios As System.Timers.Timer
    Friend WithEvents tmr05BitacoraAut As System.Timers.Timer

End Class
