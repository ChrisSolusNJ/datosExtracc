Imports System.IO
Imports System.Net
Imports System.Data.SqlClient

Friend Class clsU_00101ConstantesYEnums

  

    Friend Function fNombreServidorLocal() As String

        Dim strServer As String
        strServer = fHostName()
        Return strServer & "\SQLEXPRESS"
        strServer = Nothing
        GC.Collect()

    End Function

    Private Function fHostName() As String
        Return My.Computer.Name
    End Function


   
    Friend Const cUsuarioEjecutaMCM As String = "MCM2010Ejecuta"
    Friend Const cPswUsuarioEjecutaMCM As String = "@User@"
    Friend Const cUsuarioEjecuta As String = "MCM2010Ejecuta"
    Friend Const cPswUsuarioEjecuta As String = "@User@"
    '++++++++++++++++++++   CONSTANTES   ++++++++++++++++++++++++++++++++++++++++++++++++++

   

    Friend Sub SettingsConnectKCC(ByRef o_Server As String, ByRef o_PSW As String, ByRef o_USR As String)

        Dim intEnumType As Int16
        Dim clsU_SQL As New clsU_00201ConexionSQL
        Dim rdr As SqlDataReader
        Dim strSQL As String
        Dim clsUEncrypt As New clsU_01201_Encrypt

        intEnumType = enSQLCommTypes.Type_SP


        strSQL = "pa_002_SettingsKCC"

        With clsU_SQL.fcmSQLEjecutaSETTINGS("TLX043MXDB", intEnumType, strSQL)
            rdr = .ExecuteReader
            With rdr
                While .Read
                    o_Server = .GetValue(0)
                    o_PSW = clsUEncrypt.Decrypt_LogMaquinas(.GetValue(1))
                    o_USR = clsUEncrypt.Decrypt_LogMaquinas(.GetValue(2))
                End While
            End With
            .Connection.Close()
            .Dispose()
        End With


        intEnumType = Nothing
        clsU_SQL = Nothing
        rdr = Nothing
        strSQL = Nothing
        clsUEncrypt = Nothing

        GC.Collect()

    End Sub

    Friend Function fNombreServidorSETTINGS() As String

        Dim objStreamReader As StreamReader
        Dim strLine As String

        Dim strServer As String

        If File.Exists("C:\MCM\ModoLogTags.txt") Then

            objStreamReader = New StreamReader("C:\MCM\ModoLogTags.txt")
            strLine = objStreamReader.ReadLine
            strLine = objStreamReader.ReadLine
            strServer = strLine
            'Console.WriteLine(strServer)
            objStreamReader.Close()

            fNombreServidorSETTINGS = strServer
        Else
            EventLog.WriteEntry("LogServMaquinas", "No existe el archivo C:\MCM\ModoLogTags.txt")
        End If
        
        objStreamReader = Nothing
        strLine = Nothing
        strServer = Nothing

        GC.Collect()

    End Function

    '++++++++++++++++++++   ENUMS   ++++++++++++++++++++++++++++++++++++++++++++++++++
    Friend Enum enSQLCommTypes
        Type_SP = 4
        Type_TableDirect = 512
        Type_Text = 1
    End Enum
    '++++++++++++++++++++   ENUMS   ++++++++++++++++++++++++++++++++++++++++++++++++++

  

End Class
