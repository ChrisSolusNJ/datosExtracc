'Imports System.Windows.Forms
Imports System.Data.SqlClient
Imports System.Data
Imports Microsoft.VisualBasic

Friend Class clsU_00401Utils

   

    ' Funci�n para obtener el No de maquina que se guarda en el archivo de texto 
    Friend Function fNoMaquina() As Int16
        Dim oFile As System.IO.File
        Dim oRead As System.IO.StreamReader

        oRead = IO.File.OpenText("C:\ArchivosBitacoraAut\Maquina.txt")
        fNoMaquina = CInt(oRead.ReadLine())

        oRead.Close()
        oRead.Dispose()
        oRead = Nothing
        oFile = Nothing

        GC.Collect()

    End Function

    ' Funci�n para obtener el Nombre de la estaci�n en que se lee el servicio 
    Friend Function fNombreMaquina() As String
        Dim oFile As System.IO.File
        Dim oRead As System.IO.StreamReader

        oRead = IO.File.OpenText("C:\ArchivosBitacoraAut\Maquina.txt")
        oRead.ReadLine()
        fNombreMaquina = oRead.ReadLine()

        oRead.Close()
        oRead.Dispose()
        oRead = Nothing
        oFile = Nothing

        GC.Collect()

    End Function

    Friend Function fFechaCalc() As Date
        Try
            Dim Hora As TimeSpan
            Dim tsPrimerT As New TimeSpan(0, 7, 0, 0)
            Dim OneDay As New TimeSpan(1, 0, 0, 0)

            Hora = Date.Now.TimeOfDay
            If Hora < tsPrimerT Then
                fFechaCalc = Date.Today.Subtract(OneDay)
            Else
                fFechaCalc = Date.Today
            End If

            Hora = Nothing
            tsPrimerT = Nothing
            OneDay = Nothing
        Catch ex As Exception
            MsgBox("clsU_fFechaCalc: " & Err.Description)
        End Try
        GC.Collect()
    End Function
   
    Friend Function fTurnoActual() As Byte
        Try
            Dim lahora As TimeSpan
            Dim tsPrimerT As New TimeSpan(0, 7, 0, 0)
            Dim tsSegundoT As New TimeSpan(0, 15, 0, 0)
            Dim tsTercerT As New TimeSpan(0, 23, 0, 0)

            lahora = Date.Now.TimeOfDay
            If lahora = tsPrimerT Or lahora > tsPrimerT And lahora < tsSegundoT Then
                fTurnoActual = 1
                'TurnoActual = lahora
            End If
            If lahora = tsSegundoT Or lahora > tsSegundoT And lahora < tsTercerT Then
                fTurnoActual = 2
                'TurnoActual = lahora
            End If
            If lahora = tsTercerT Or lahora > tsTercerT Or lahora < tsPrimerT Then
                fTurnoActual = 3
                'TurnoActual = lahora
            End If

            lahora = Nothing
            tsPrimerT = Nothing
            tsSegundoT = Nothing
            tsTercerT = Nothing
        Catch ex As Exception
            MsgBox("clsU_fTurnoActual: " & Err.Description)
        End Try
        GC.Collect()
    End Function

    Friend Function fFechaANSI(ByVal o_Fecha As Date) As String
        Dim strANSI As String
        strANSI = Format(o_Fecha, "yyyyMMdd")
        Return strANSI
    End Function


End Class
