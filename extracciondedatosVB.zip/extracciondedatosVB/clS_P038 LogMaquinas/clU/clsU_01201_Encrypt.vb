﻿Imports System.Text
Imports System.Security.Cryptography
Imports System.IO

Friend Class clsU_01201_Encrypt

    Friend Function Encrypt_LogMaquinas(clearText As String) As String

        Dim EncryptionKey As String = "wFzeILhpJ$d4Npiw"
        Dim clearBytes As Byte() = Encoding.Unicode.GetBytes(clearText)

        Using encryptor As Aes = Aes.Create()
            Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D, &H65, &H64, &H76, &H65, &H64, &H65, &H76})
            encryptor.Key = pdb.GetBytes(32)
            encryptor.IV = pdb.GetBytes(16)
            Using ms As New MemoryStream()
                Using cs As New CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write)
                    cs.Write(clearBytes, 0, clearBytes.Length)
                    cs.Close()
                End Using
                clearText = Convert.ToBase64String(ms.ToArray())
            End Using
            pdb = Nothing
        End Using

        Encrypt_LogMaquinas = clearText

        EncryptionKey = Nothing
        clearBytes = Nothing

        GC.Collect()

    End Function

    Friend Function Decrypt_LogMaquinas(clearText As String) As String

        Dim EncryptionKey As String = "wFzeILhpJ$d4Npiw"
        Dim clearBytes As Byte() = Convert.FromBase64String(clearText)

        Using encryptor As Aes = Aes.Create()
            Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D, &H65, &H64, &H76, &H65, &H64, &H65, &H76})
            encryptor.Key = pdb.GetBytes(32)
            encryptor.IV = pdb.GetBytes(16)
            Using ms As New MemoryStream()
                Using cs As New CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write)
                    cs.Write(clearBytes, 0, clearBytes.Length)
                    cs.Close()
                End Using
                clearText = Encoding.Unicode.GetString(ms.ToArray())
            End Using
            pdb = Nothing
        End Using

        Decrypt_LogMaquinas = clearText

        EncryptionKey = Nothing
        clearBytes = Nothing

        GC.Collect()

    End Function

    Friend Function strGeneraContrasena(intLongitud As Integer) As String

        Dim validchars As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890@$"
        Dim sb As New StringBuilder()
        Dim rand As New Random()
        For i As Integer = 1 To 16
            Dim idx As Integer = rand.Next(0, validchars.Length)
            Dim randomChar As Char = validchars(idx)
            sb.Append(randomChar)
        Next i

        Dim randomString = sb.ToString()

        strGeneraContrasena = randomString

    End Function

    Friend Function Encrypt(clearText As String, EncryptionKey As String) As String

        'Dim EncryptionKey As String = "$XwuxCedSUgtPx0V"
        Dim clearBytes As Byte() = Encoding.Unicode.GetBytes(clearText)

        Using encryptor As Aes = Aes.Create()
            Dim pdb As New Rfc2898DeriveBytes(EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D, &H65, &H64, &H76, &H65, &H64, &H65, &H76})
            encryptor.Key = pdb.GetBytes(32)
            encryptor.IV = pdb.GetBytes(16)
            Using ms As New MemoryStream()
                Using cs As New CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write)
                    cs.Write(clearBytes, 0, clearBytes.Length)
                    cs.Close()
                End Using
                clearText = Convert.ToBase64String(ms.ToArray())
            End Using
            pdb = Nothing
        End Using

        Encrypt = clearText

        clearBytes = Nothing

        GC.Collect()

    End Function

    Friend Function Decrypt_Encrypt(o_DecryptionKey As String, o_Cadena As String, o_EncryptionKey As String) As String

        'Dim DencryptionKey As String = "$XwuxCedSUgtPx0V"
        Dim clearBytes As Byte() = Convert.FromBase64String(o_Cadena)

        Using Decryptor As Aes = Aes.Create()
            Dim pdb1 As New Rfc2898DeriveBytes(o_DecryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D, &H65, &H64, &H76, &H65, &H64, &H65, &H76})
            Decryptor.Key = pdb1.GetBytes(32)
            Decryptor.IV = pdb1.GetBytes(16)
            Using ms1 As New MemoryStream()
                Using cs As New CryptoStream(ms1, Decryptor.CreateDecryptor(), CryptoStreamMode.Write)
                    cs.Write(clearBytes, 0, clearBytes.Length)
                    cs.Close()
                End Using
                o_Cadena = Encoding.Unicode.GetString(ms1.ToArray())
            End Using
            pdb1 = Nothing
        End Using

        'Return clearText

        clearBytes = Encoding.Unicode.GetBytes(o_Cadena)

        Using encryptor As Aes = Aes.Create()
            Dim pdb As New Rfc2898DeriveBytes(o_EncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D, &H65, &H64, &H76, &H65, &H64, &H65, &H76})
            encryptor.Key = pdb.GetBytes(32)
            encryptor.IV = pdb.GetBytes(16)
            Using ms As New MemoryStream()
                Using cs As New CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write)
                    cs.Write(clearBytes, 0, clearBytes.Length)
                    cs.Close()
                End Using
                o_Cadena = Convert.ToBase64String(ms.ToArray())
            End Using
            pdb = Nothing
        End Using

        Decrypt_Encrypt = o_Cadena

        clearBytes = Nothing

        GC.Collect()

    End Function



End Class
