Imports System.Data.SqlClient
Imports System.Data

Friend Class clsU_00201ConexionSQL
    Private strNombreServidor As String
    Private strNombreUsuarioConsulta As String
    Private strPswUsarioConsulta As String
    Private strCadenaConexion As String
    Private strNombreUsuarioEjecuta As String
    Private strPswUsarioEjecuta As String

   

    Friend Function fcmSQLEjecutaKCC(strBD As String, intCommType As Integer, _
      strCommText As String) As SqlCommand

        'Try
        Dim cn As SqlConnection
        Dim cm As SqlCommand
        Dim clConstantes As New clsU_00101ConstantesYEnums

        clConstantes.SettingsConnectKCC(strNombreServidor, strPswUsarioEjecuta, strNombreUsuarioEjecuta)
        strCadenaConexion = "Data Source = " & strNombreServidor & "; Initial Catalog = " & _
        strBD & "; User ID = " & strNombreUsuarioEjecuta & "; Password = " & strPswUsarioEjecuta '& _
        '"; Max Pool Size = 500"
        cn = New SqlConnection(strCadenaConexion)
        cn.Open()
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandType = intCommType
        cm.CommandText = strCommText
        cm.CommandTimeout = 120000
        clConstantes = Nothing
        Return cm

        clConstantes = Nothing
        cm = Nothing
        'cn.Close()
        cn = Nothing

        GC.Collect()
    End Function

    Friend Function fcmSQLEjecutaSETTINGS(strBD As String, intCommType As Integer, _
      strCommText As String) As SqlCommand

        'Try
        Dim cn As SqlConnection
        Dim cm As SqlCommand
        Dim clConstantes As New clsU_00101ConstantesYEnums

        'strNombreServidor = clConstantes.cNombreServidor
        strNombreServidor = clConstantes.fNombreServidorSETTINGS
        strNombreUsuarioEjecuta = clsU_00101ConstantesYEnums.cUsuarioEjecuta
        strPswUsarioEjecuta = clsU_00101ConstantesYEnums.cPswUsuarioEjecuta
        strCadenaConexion = "Data Source = " & strNombreServidor & "; Initial Catalog = " & _
        strBD & "; User ID = " & strNombreUsuarioEjecuta & "; Password = " & strPswUsarioEjecuta '& _
        '"; Max Pool Size = 500"
        cn = New SqlConnection(strCadenaConexion)
        cn.Open()
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandType = intCommType
        cm.CommandText = strCommText
        cm.CommandTimeout = 120000
        'clConstantes = Nothing
        fcmSQLEjecutaSETTINGS = cm

        clConstantes = Nothing
        cm = Nothing
        'cn.Close()
        cn = Nothing

        GC.Collect()
    End Function

    Friend Function fProbarConexionSQLSETTINGS() As Boolean

        Dim cn As SqlConnection
        Dim cm As SqlCommand
        Dim clConstantes As New clsU_00101ConstantesYEnums

        Try

            'strNombreServidor = clConstantes.cNombreServidor
            strNombreServidor = clConstantes.fNombreServidorSETTINGS
            strNombreUsuarioEjecuta = clsU_00101ConstantesYEnums.cUsuarioEjecuta
            strPswUsarioEjecuta = clsU_00101ConstantesYEnums.cPswUsuarioEjecuta
            strCadenaConexion = "Data Source = " & strNombreServidor & "; Initial Catalog = TLX043MXDB" & _
            "; User ID = " & strNombreUsuarioEjecuta & "; Password = " & strPswUsarioEjecuta '& _
            '"; Max Pool Size = 500"
            'EventLog.WriteEntry("LogServMaquinas", "fProbarConexionSQLSETTINGS " & strCadenaConexion)
            cn = New SqlConnection(strCadenaConexion)
            cn.Open()

        Catch Exp As Exception
            EventLog.WriteEntry("LogServMaquinas", Exp.Message)
            Return False
        Finally
            clConstantes = Nothing
            cm = Nothing
            'cn.Close()
            cn = Nothing
        End Try
        EventLog.WriteEntry("LogServMaquinas", "Conexion a fProbarConexionSQLSETTINGS exitosa")
        Return True

        clConstantes = Nothing
        cm = Nothing
        cn = Nothing

        GC.Collect()

    End Function

    Friend Function fProbarConexionSQLKCC() As Boolean

        Dim cn As SqlConnection
        Dim cm As SqlCommand
        Dim clConstantes As New clsU_00101ConstantesYEnums

        Try
            clConstantes.SettingsConnectKCC(strNombreServidor, strPswUsarioEjecuta, strNombreUsuarioEjecuta)
            'EventLog.WriteEntry("LogServMaquinas", strNombreServidor & ", " & strPswUsarioEjecuta & ", " & strNombreUsuarioEjecuta)

            strCadenaConexion = "Data Source = " & strNombreServidor & "; Initial Catalog = TLX043MXDB" & _
            "; User ID = " & strNombreUsuarioEjecuta & "; Password = " & strPswUsarioEjecuta '& _
            '"; Max Pool Size = 500"
            'EventLog.WriteEntry("LogServMaquinas", "fProbarConexionSQLKCC " & strCadenaConexion)
            cn = New SqlConnection(strCadenaConexion)
            cn.Open()
            clConstantes = Nothing

        Catch Exp As Exception
            EventLog.WriteEntry("LogServMaquinas", Exp.Message)
            Return False
        Finally
            clConstantes = Nothing
            cm = Nothing
            cn = Nothing
        End Try
        EventLog.WriteEntry("LogServMaquinas", "Conexion a fProbarConexionSQLKCC exitosa")
        Return True

        clConstantes = Nothing
        cm = Nothing
        cn = Nothing

        GC.Collect()
    End Function


  

    Friend Function fcmSQLEjecutaLocal(ByVal strBD As String, ByVal intCommType As Integer, _
   ByVal strCommText As String) As SqlCommand

        'Try
        Dim cn As SqlConnection
        Dim cm As SqlCommand
        Dim clConstantes As New clsU_00101ConstantesYEnums

        strNombreServidor = clConstantes.fNombreServidorLocal
        strNombreUsuarioEjecuta = clsU_00101ConstantesYEnums.cUsuarioEjecutaMCM
        strPswUsarioEjecuta = clsU_00101ConstantesYEnums.cPswUsuarioEjecutaMCM
        strCadenaConexion = "Data Source = " & strNombreServidor & "; Initial Catalog = " & _
        strBD & "; User ID = " & strNombreUsuarioEjecuta & "; Password = " & strPswUsarioEjecuta
        cn = New SqlConnection(strCadenaConexion)
        cn.Open()
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandType = intCommType
        cm.CommandText = strCommText
        fcmSQLEjecutaLocal = cm

        clConstantes = Nothing
        cm = Nothing
        'cn.Close()
        cn = Nothing
        'Catch
        '    If Err.Number = 5 Then
        '        MsgBox("clsU_ No se ha podido conectar al servidor SQL")
        '    Else
        '        MsgBox("Error en fcmSQLEjecuta: " & Err.Description & " " & Err.Number)
        '    End If

        'End Try
        GC.Collect()
    End Function

End Class
