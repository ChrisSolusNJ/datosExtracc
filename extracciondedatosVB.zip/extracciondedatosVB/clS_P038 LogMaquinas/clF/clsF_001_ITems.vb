﻿Public Class clsF_001_ITems
    Dim clsU_Utils As New clsU_00401Utils


    Friend Function fCortesActual(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fCortesActual = "[MMC]Mes_ReporteProduccion[0,1]"

        End Select
    End Function

    Friend Function fRechazos(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fRechazos = "[MMC]Mes_ReporteProduccion[0,2]"

        End Select
    End Function

    Friend Function fMinParo(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fMinParo = "[MMC]Mes_ReporteProduccion[0,3]"

        End Select
    End Function

    Friend Function fMinEnhebrando(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fMinEnhebrando = "[MMC]Mes_ReporteProduccion[0,4]"

        End Select
    End Function

    Friend Function fMinCorriendo(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fMinCorriendo = "[MMC]Mes_ReporteProduccion[0,5]"

        End Select
    End Function

    Friend Function fMermaMaquina(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fMermaMaquina = "[MMC]Mes_ReporteProduccion[0,9]"

        End Select
    End Function

    Friend Function fTiempoPerdido(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fTiempoPerdido = "[MMC]Mes_ReporteProduccion[0,10]"

        End Select
    End Function

    Friend Function fParoMaqina(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fParoMaqina = "[MMC]Mes_ReporteProduccion[0,11]"

        End Select
    End Function

    Friend Function MachineRune(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                MachineRune = "[MMC]Mes_ReporteProduccion[0,15]"

        End Select
    End Function

    Friend Function fVelPromMaquina(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fVelPromMaquina = "[MMC]Mes_ReporteProduccion[0,16]"

        End Select
    End Function

    Friend Function fVelStPointMaquina(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fVelStPointMaquina = "[MMC]Mes_ReporteProduccion[0,17]"

        End Select
    End Function

    Friend Function fTurnoAnterior(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fTurnoAnterior = "[MMC]Mes_ReporteProduccion[0,18]"

        End Select
    End Function

    Friend Function fTiempoporParo(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fTiempoporParo = "[MMC]Mes_ReporteProduccion[0,19]"

        End Select
    End Function

    Friend Function fGolpes(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fGolpes = "[MMC]Mes_ReporteProduccion[0,20]"

        End Select
    End Function

    Friend Function fHoraId(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fHoraId = "[MMC]Mes_ReporteProduccion[0,21]"

        End Select
    End Function

    Friend Function fMaquinaArribaAbajo(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fMaquinaArribaAbajo = "[MMC]Mes_ReporteProduccion[0,22]"

        End Select
    End Function

    Friend Function fSeccion(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fSeccion = "[MMC]Mes_ReporteProduccion[0,23]"

        End Select
    End Function

    Friend Function fModulo(ByVal o_NoMaquina As Int16) As String
        Select Case o_NoMaquina
            Case CInt(clsU_Utils.fNoMaquina)
                fModulo = "[MMC]Mes_ReporteProduccion[0,24]"

        End Select
    End Function

End Class