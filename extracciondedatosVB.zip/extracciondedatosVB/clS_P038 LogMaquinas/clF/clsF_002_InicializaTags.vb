﻿Imports OPCAutomation
Imports System.IO
Imports System.Net
Imports System.Data.SqlClient

Friend Class clsF_002_InicializaTags


    Friend Sub InicializaAplicacion(ByRef o_blnModotxt As Boolean)

        Dim objStreamReader As StreamReader
        Dim strLine As String

        Dim strServer As String

        If File.Exists("C:\MCM\ModoLogTags.txt") Then

            o_blnModotxt = True

        Else

            o_blnModotxt = False


        End If

        objStreamReader = Nothing
        strLine = Nothing
        strServer = Nothing

        GC.Collect()

    End Sub


    Friend Sub sServiceStart(ByRef Obj1 As Object, ByRef Obj2 As Object, ByRef clstrItms As Automation.clItems.strucItms, clstrVars As Automation.clItems.strucVars)

        ''//////////////////////////////////////////////////////////////////////////////
        'Dim watch As Stopwatch = Stopwatch.StartNew()
        ''//////////////////////////////////////////////////////////////////////////////

        Dim clsU_Utils As New clsU_00401Utils
        Dim clItms As New clsF_001_ITems
        Dim o_NoMaquina As Integer
        Dim i As Integer = 0
        Dim e As Double = 0
        Dim n As Integer = 100
        Dim strItem As String = ""
        Dim intModo As Integer

        Try

            Dim objStreamReader As StreamReader
            Dim strLine As String
            Dim strMode As String
            Dim strServer As String

            If File.Exists("C:\MCM\ModoLogTags.txt") Then

                objStreamReader = New StreamReader("C:\MCM\ModoLogTags.txt")
                strLine = objStreamReader.ReadLine
                strMode = strLine
                objStreamReader.Close()

                intModo = CInt(strMode)

            Else
                EventLog.WriteEntry("LogServMaquinas", "No existe el archivo C:\MCM\ModoLogTags.txt")
            End If

            objStreamReader = Nothing
            strLine = Nothing
            strMode = Nothing
            strServer = Nothing

            EventLog.WriteEntry("LogServMaquinas", "Obtener tags OPC: " & DateTime.Now.ToString)

            o_NoMaquina = clsU_Utils.fNoMaquina()


            EventLog.WriteEntry("LogServMaquinas", "Máquina: " & o_NoMaquina.ToString)

            'Corte Actual
            clstrVars.o_Var1 = clItms.fCortesActual(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fCortesActual")

            'Rechazos Actual
            clstrVars.o_Var2 = clItms.fRechazos(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fRechazos")

            'Minutos Paro Actual
            clstrVars.o_Var3 = clItms.fMinParo(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fMinParo")

            'Minutos Enhebrando Actual
            clstrVars.o_Var4 = clItms.fMinEnhebrando(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fMinEnhebrando")

            'Minutos Corriendo Actual
            clstrVars.o_Var5 = clItms.fMinCorriendo(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fMinCorriendo")

            'Merma Maquina Actual
            clstrVars.o_Var6 = clItms.fMermaMaquina(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fMermaMaquina")

            'Tiempo Perdido Actual
            clstrVars.o_Var7 = clItms.fTiempoPerdido(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fTiempoPerdido")

            'Paro MaqinaActual
            clstrVars.o_Var8 = clItms.fParoMaqina(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fParoMaqina")

            'Maquina Arriba o Abajo
            clstrVars.o_Var9 = clItms.MachineRune(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "MachineRune")

            'Velocidad Promedio
            clstrVars.o_Var10 = clItms.fVelPromMaquina(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fVelPromMaquina")

            'VelMaquina
            clstrVars.o_Var11 = clItms.fVelStPointMaquina(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fVelStPointMaquina")

            'Turno Actual
            clstrVars.o_Var12 = clItms.fTurnoAnterior(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fTurnoAnterior")

            'Tiempo por Paro
            clstrVars.o_Var13 = clItms.fTiempoporParo(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fTiempoporParo")

            'Golpes
            clstrVars.o_Var14 = clItms.fGolpes(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fGolpes")

            'Hora Id
            clstrVars.o_Var15 = clItms.fHoraId(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fHoraId")

            'fParo Maquina Anterior
            clstrVars.o_Var16 = clItms.fMaquinaArribaAbajo(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fMaquinaArribaAbajo")

            'Seccion
            clstrVars.o_Var17 = clItms.fSeccion(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fSeccion")

            'Modulo
            clstrVars.o_Var18 = clItms.fModulo(o_NoMaquina)
            EventLog.WriteEntry("LogServMaquinas", "fModulo")

            Dim clsAutom As New Automation.Kepware

            clsAutom.subGet(Obj1, Obj2, clstrItms, clstrVars)

            clsAutom = Nothing

            GC.Collect()

            EventLog.WriteEntry("LogServMaquinas", "sInitCnn")
            '****************************************************************************************************

            EventLog.WriteEntry("LogServMaquinas", "Inicia Delay para lectura de Tags, " & e.ToString)

            For e = 0 To 10000000000
                e = e + 1
            Next

            EventLog.WriteEntry("LogServMaquinas", "Termina Delay para lectura de Tags, " & e.ToString)
            EventLog.WriteEntry("LogServMaquinas", "Se obtuvieron correctamente todos los Tags: " & DateTime.Now)

        Catch
            EventLog.WriteEntry("LogServMaquinas", "Error serviceStart Conexión a RsLinx y Tags: " & Err.Description & DateTime.Now.ToString)
        End Try

        clsU_Utils = Nothing
        o_NoMaquina = Nothing
        i = Nothing
        e = Nothing
        n = Nothing
        strItem = Nothing
        intModo = Nothing

        GC.Collect()



    End Sub


End Class
