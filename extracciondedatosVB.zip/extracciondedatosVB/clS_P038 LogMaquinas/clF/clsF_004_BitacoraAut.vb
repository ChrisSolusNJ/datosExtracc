﻿Imports OPCAutomation
Imports System.Diagnostics0

Friend Class clsF_004_BitacoraAut


    Friend Sub stmrLineRun_ElapsedVelProm(ByRef clstrItms As Automation.clItems.strucItms)

        

        Dim strSQL As String
        Dim intType As Int16
        Dim clsU_SQL As New clsU_00201ConexionSQL

        intType = clsU_00101ConstantesYEnums.enSQLCommTypes.Type_SP

        Dim blnReadWrite As Boolean
        'Dim strSQL As String
        'Dim intType As Int16
        Dim clsU_ConstantesYEnumas As New clsU_00101ConstantesYEnums
        'Dim clsU_SQL As New clsU_00201ConexionSQL
        Dim strNombreEstacion As String
        Dim intNoMaquina As Int16
        Dim datFechaBitacora As Date
        Dim strFechaBitacora As String
        Dim blnHabilitaMensajes As Boolean
        Dim intTurno As Integer
        Dim clsU_Utils As New clsU_00401Utils

        intNoMaquina = CInt(clsU_Utils.fNoMaquina)
        strNombreEstacion = clsU_Utils.fNombreMaquina
        intTurno = clsU_Utils.fTurnoActual
        datFechaBitacora = clsU_Utils.fFechaCalc
        strFechaBitacora = clsU_Utils.fFechaANSI(datFechaBitacora)

       

            'intType = clsU_ConstantesYEnumas.enSQLCommTypes.Type_SP
            strSQL = "pa_P007_clsS_0101_LineRunVelProm"

        'With clsU_SQL.fcmSQLEjecutaRemoto("TLX001MXDB", intType, strSQL)
        With clsU_SQL.fcmSQLEjecutaKCC("TLX004MXDB", intType, strSQL)
            .Parameters.AddWithValue("@Fecha", strFechaBitacora)
            .Parameters.AddWithValue("@Turno", intTurno)
            .Parameters.AddWithValue("@NoMaquina", 74)
            .Parameters.AddWithValue("@IdEncabezadoBitacora", 0).Direction = ParameterDirection.Output
            .Parameters("@IdEncabezadoBitacora").Size = 16

            'Corte Actual
            .Parameters.AddWithValue("@Cortes", clstrItms.o_OPCItm1.Value)
            'Rechazos Actual
            .Parameters.AddWithValue("@Rechazos", clstrItms.o_OPCItm2.Value)
            'Minutos Paro Actual
            .Parameters.AddWithValue("@TAbajo", (clstrItms.o_OPCItm3.Value))
            'Minutos Enhebrando Actual
            .Parameters.AddWithValue("@fMinEnhebrandoActual", (clstrItms.o_OPCItm4.Value))
            'Minutos Corriendo Acrtual
            .Parameters.AddWithValue("@TArriba", (clstrItms.o_OPCItm5.Value))
            'Merma Maquina Actual
            .Parameters.AddWithValue("@fMermaMaquinaActual", (clstrItms.o_OPCItm6.Value))
            'Tiempo Perdido Actual
            .Parameters.AddWithValue("@fTiempoPerdidoActual", (clstrItms.o_OPCItm7.Value))
            'Paro Maqina Actual
            .Parameters.AddWithValue("@fParoMaqinaActual", (clstrItms.o_OPCItm8.Value))
            'Maquina Arriba o Abajo
            .Parameters.AddWithValue("@LineRun", CBool(clstrItms.o_OPCItm9.Value))
            'Velocidad Promedio
            .Parameters.AddWithValue("@VelProm", (clstrItms.o_OPCItm10.Value))
            'VelMaquina
            .Parameters.AddWithValue("@fVelStp", (clstrItms.o_OPCItm11.Value))
            'Turno Actial
            .Parameters.AddWithValue("@fTurnoAnterior", (clstrItms.o_OPCItm12.Value))
            'Tiempo por Paro
            .Parameters.AddWithValue("@TParo", (clstrItms.o_OPCItm13.Value))
            'Golpes
            .Parameters.AddWithValue("@fGolpes", (clstrItms.o_OPCItm14.Value))
            'Hora Id
            .Parameters.AddWithValue("@HoraId", (clstrItms.o_OPCItm15.Value))
            'Maquina Arriba Abajo
            .Parameters.AddWithValue("@fMaquinaArribaAbajo", (clstrItms.o_OPCItm16.Value))
            'Seccion
            .Parameters.AddWithValue("@fSeccion", (clstrItms.o_OPCItm17.Value))
            'Modulo
            .Parameters.AddWithValue("@fModulo", (clstrItms.o_OPCItm18.Value))

            .ExecuteNonQuery()
            .Connection.Close()
            .Dispose()
        End With



        blnReadWrite = Nothing
            clsU_ConstantesYEnumas = Nothing
            strNombreEstacion = Nothing
            intNoMaquina = Nothing
            datFechaBitacora = Nothing
            strFechaBitacora = Nothing
            blnHabilitaMensajes = Nothing
            intTurno = Nothing
            clsU_Utils = Nothing



            strSQL = Nothing
            intType = Nothing
            clsU_SQL = Nothing

            ''//////////////////////////////////////////////////////////////////////////////

            GC.Collect()
    End Sub

End Class
