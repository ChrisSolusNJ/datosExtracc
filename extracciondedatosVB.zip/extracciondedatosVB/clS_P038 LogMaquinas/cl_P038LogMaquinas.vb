﻿Imports OPCAutomation
Imports System.ServiceProcess

Public Class cl_P038LogMaquinas

   
    Dim intNoMaquina As Int16
    Dim NoDef As Integer
   

    Dim blnEstado As Boolean = False
    Dim blnModotxt As Boolean
    Dim strMensaje As String

    Dim strNombreServidorKCC
    Dim strNombreusuarioSQLKCC
    Dim strPswUsuarioSQLKCC
    Dim Bloque(26) As Boolean

    Dim obj1 As Object
    Dim obj2 As Object
    Dim obj3 As Automation.clItems.strucItms
    Dim obj4 As Automation.clItems.strucVars


    Protected Overrides Sub OnStart(ByVal args() As String)
        EventLog.WriteEntry("LogServMaquinas arrancó correctamente")

        Try
            'Habilita Timer para inicio de la aplicación
            tmr01InicioServicio.Enabled = True

            Dim clsU_Const As New clsU_00101ConstantesYEnums
            'Nombre del servidor SQL server, para saber si no se encuentra en modo de prueba
            EventLog.WriteEntry("SERVIDOR LOCAL: " & clsU_Const.fNombreServidorLocal)
            'EventLog.WriteEntry("SERVIDOR REMOTO: " & clsU_Const.fNombreServidorRemoto)
            clsU_Const = Nothing

        Catch ex As Exception
            EventLog.WriteEntry("clsS_OnStartLogServMaquinas: " & Err.Description)
        End Try
        GC.Collect()
    End Sub

    Protected Overrides Sub OnStop()
        ' Add code here to perform any tear-down necessary to stop your service.

        Try

            Dim clsAutom As New Automation.Kepware

            clsAutom.subClose(obj1)

            clsAutom = Nothing


            GC.Collect()

        Catch ex As Exception
            EventLog.WriteEntry("OnStop: " & Err.Description)
        End Try
        GC.Collect()

    End Sub

    Private Sub tmr01InicioServicio_Elapsed(sender As Object, e As Timers.ElapsedEventArgs) Handles tmr01InicioServicio.Elapsed
        Try
            'Este timer se usa solo para poder acceder al debug, ya que no se puede acceder directamente al Start del servicio
            tmr01InicioServicio.Stop()
            tmr01InicioServicio.Enabled = False
            '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            Dim clsFIniTags As New clsF_002_InicializaTags
            Dim service As ServiceController = New ServiceController("LogServMaquinas")

            clsFIniTags.InicializaAplicacion(blnModotxt)


            If blnModotxt = True Then

                EventLog.WriteEntry("SI existe el archivo C:\MCM\ModoLogTags.txt")

                tmr02Conexion.Enabled = True
                EventLog.WriteEntry("Servicio LogServMaquinas Iniciado")

            Else
                EventLog.WriteEntry("No existe el archivo C:\MCM\ModoLogTags.txt, servicio detenido, se requiere el archivo para que pueda arrancar el servicio")

                service.Stop()

            End If

            clsFIniTags = Nothing
            service = Nothing
            ''+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        Catch
            EventLog.WriteEntry("tmr01InicioServicio_Elapsed: " & Err.Description)
        End Try

        GC.Collect()
    End Sub

    Private Sub tmr02Conexion_Elapsed(sender As Object, e As Timers.ElapsedEventArgs) Handles tmr02Conexion.Elapsed
        Try
            tmr02Conexion.Stop()
            tmr02Conexion.Enabled = False

            Dim clsUtils As New clsU_00401Utils
            Dim clsfInicializaTags As New clsF_002_InicializaTags
            Dim clsSQl As New clsU_00201ConexionSQL

            intNoMaquina = clsUtils.fNoMaquina

            '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            'intNoTagsVerifica las conexiones a SQL Local y al servidor de datos KCC

            'If clsSQl.fProbarConexionSQLSETTINGS() Then
            '    EventLog.WriteEntry("Se probo con exito la conectividad al servidor local SETTINGS")
            '    If clsSQl.fProbarConexionSQLKCC Then
            '        EventLog.WriteEntry("Se probo con exito la conectividad al servidor KCC")

            '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            '////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            Dim clsAutom As New Automation.Kepware

            clsfInicializaTags.sServiceStart(obj1, obj2, obj3, obj4)

            EventLog.WriteEntry("Conectado a RSLinx ")

            ' ''+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            '////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            tmr03IniciaServicios.Enabled = True

            '    Else
            '        EventLog.WriteEntry("No se pudo comprobar la conectividad al servidor KCC")
            '    End If
            'Else
            '    EventLog.WriteEntry("No se pudo comprobar la conectividad al servidor local SETTINGS")

            'End If

            clsUtils = Nothing
            clsfInicializaTags = Nothing
            clsSQl = Nothing
            clsAutom = Nothing

        Catch
            EventLog.WriteEntry("tmr02Conexion_Elapsed: " & Err.Description)
        End Try

        GC.Collect()
    End Sub


    Private Sub tmr03IniciaServicios_Elapsed(sender As Object, e As Timers.ElapsedEventArgs) Handles tmr03IniciaServicios.Elapsed

        Try
            tmr03IniciaServicios.Stop()
            tmr03IniciaServicios.Enabled = False


            Dim clsUtils As New clsU_00401Utils
            Dim intNoMaquina As Integer

            intNoMaquina = clsUtils.fNoMaquina


            'Habilita captura BitacoraAut
            tmr05BitacoraAut.Enabled = True
            EventLog.WriteEntry("Habilita captura BitacoraAut")

            '' '' ''++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            ' '' ''If Bloque(3) = True Then
            ' '' ''    'Habilita captura ProduccionAut
            ' '' ''    tmr11CambioTurno.Enabled = True
            ' '' ''    EventLog.WriteEntry("Habilita captura ProduccionAut")

            ' '' ''    '++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            ' '' ''End If
            '' '' ''++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            ' '' ''If Bloque(7) = True Then
            ' '' ''    'Habilita captura Supervisory
            ' '' ''    tmr08Supervisory.Enabled = True
            ' '' ''    EventLog.WriteEntry("Habilita captura Supervisory")
            ' '' ''    'End If
            ' '' ''End If

            clsUtils = Nothing
            intNoMaquina = Nothing

        Catch
            EventLog.WriteEntry("tmr03IniciaServicios_Elapsed: " & Err.Description)
        End Try

        GC.Collect()

    End Sub


    Private Sub tmr05BitacoraAut_Elapsed(sender As Object, e As Timers.ElapsedEventArgs) Handles tmr05BitacoraAut.Elapsed
        If blnEstado = False Then
            tmr05BitacoraAut.Stop()

            Try

                Dim clF_BitacoraAut As New clsF_004_BitacoraAut
                Dim clsUtils As New clsU_00401Utils

                clF_BitacoraAut.stmrLineRun_ElapsedVelProm(obj3)

                'EventLog.WriteEntry("Cortes: " & obj3.o_OPCItm1.Value.ToString)

                clF_BitacoraAut = Nothing
                clsUtils = Nothing

            Catch
                EventLog.WriteEntry("tmr05BitacoraAut_Elapsed: " & Err.Description)
            End Try
            GC.Collect()

            tmr05BitacoraAut.Start()
        End If
    End Sub
End Class
